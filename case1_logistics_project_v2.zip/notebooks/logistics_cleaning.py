import pandas as pd

# Load raw data
df=pd.read_csv('orders_raw.csv')

# Remove duplicates
df=df.drop_duplicates()

# Remove rows with missing address or postcode
df=df.dropna(subset=['address','postcode'])

# Export cleaned file
df.to_csv('orders_clean.csv',index=False)
