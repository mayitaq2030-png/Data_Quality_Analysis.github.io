-- Detect invalid addresses
SELECT * FROM orders
WHERE address IS NULL
   OR postcode IS NULL;

-- Detect duplicate order IDs
SELECT order_id, COUNT(*)
FROM orders
GROUP BY order_id
HAVING COUNT(*) > 1;
